import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BufferProgram {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        StringTokenizer st = new StringTokenizer(in.readLine());
        int c = Integer.parseInt(st.nextToken());
        int d = Integer.parseInt(st.nextToken());
        System.out.println(c + " " + d);

        st = new StringTokenizer(in.readLine(),",");
        int e = Integer.parseInt(st.nextToken());
        int f = Integer.parseInt(st.nextToken());
        System.out.println(e + " " + f);
    }
}