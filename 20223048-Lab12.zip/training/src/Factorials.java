// ****************************************************************
// Factorials.java
//
// Reads integers from the user and prints the factorial of each.
// Factorials method
// ****************************************************************

import java.util.Scanner;

public class Factorials
{
    public static void main(String[] args)
    {
	char keepGoing = 'y';

	while(keepGoing.equals("y") || keepGoing.equals("Y"))
	    {
		int val = 0;
		boolean check = true;
			while(check){
				try{
					System.out.println("Enter an integer: ");
					val = scan.nextInt();
					if (val < 0)
					{
						throw new IllegalArgumentException("값은 음수가 아니어야 합니다.");
					}
					check = false;
				} catch(IllegalArgumentException e){
					System.out.println("값은 음수가 아니어야 합니다.");

			}
		}
		System.out.print("Another factorial? (y/n) ");
		System.out.println("Factorial (" + val + ") = "+ MathUtils.factorial(val));
		keepGoing = in.next().charAt(0);
	    }
    }
}
