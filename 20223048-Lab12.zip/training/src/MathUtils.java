// ****************************************************************
// MathUtils.java
//
// Provides static mathematical utility functions.
//          
// ****************************************************************

import java.math.BigInteger;

public class MathUtils
{
    //-------------------------------------------------------------
    // Returns the factorial of the argument given
    //-------------------------------------------------------------
    public static BigInteger factorial(int n)
    {
		BigInteger fac = BigInteger.ONE;
		for (int i = n; i > 1; i--) {
			fac = fac.multiply(BigInteger.valueOf(i));
		}
		return fac;
	}


}
